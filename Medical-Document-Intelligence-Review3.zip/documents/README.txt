Place optional demo medical documents here. Browser uploads are stored in LocalStorage and are not automatically copied into this folder.
