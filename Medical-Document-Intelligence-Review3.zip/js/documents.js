import {updatePatient} from "./patients.js";
import {readFile,extractMedicalData} from "./extractor.js";
export async function processFiles(patientId,fileList){
 const files=Array.from(fileList);const results=[];
 for(const file of files){
  let text="",status="Processed";
  try{text=await readFile(file)}catch(e){status="Text extraction unavailable: "+e.message}
  const extracted=extractMedicalData(text,file.name);
  updatePatient(patientId,p=>{
   p.documents=p.documents||[];
   p.documents.push({id:crypto.randomUUID(),name:file.name,type:file.type||"unknown",size:file.size,date:new Date().toISOString(),status,text:text.slice(0,30000),extracted});
   p.conditions=[...new Set([...(p.conditions||[]),...extracted.conditions])];
   p.illnesses=[...new Set([...(p.illnesses||[]),...extracted.illnesses])];
   p.doctors=[...new Set([...(p.doctors||[]),...extracted.doctors])];
   for(const med of extracted.medicines){p.prescriptions.push({date:extracted.dates[0]||new Date().toISOString().slice(0,10),doctor:extracted.doctors[0]||"Not detected",medicines:[{name:med,dose:"",frequency:"Not detected"}],source:file.name})}
   for(const lab of extracted.labs)p.labs.push({date:extracted.dates[0]||new Date().toISOString().slice(0,10),test:lab,value:"",unit:"",range:"",status:"Detected",source:file.name});
   p.timeline.push(...extracted.timeline);
  });
  results.push({name:file.name,status});
 }
 return results;
}