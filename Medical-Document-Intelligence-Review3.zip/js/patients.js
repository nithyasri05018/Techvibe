import {DEMO_PATIENTS} from "../data/demo-data.js";
const KEY="mdi_patients_v1";
function clone(x){return JSON.parse(JSON.stringify(x))}
export function loadPatients(){const raw=localStorage.getItem(KEY);if(raw)return JSON.parse(raw);const data=clone(DEMO_PATIENTS);savePatients(data);return data}
export function savePatients(p){localStorage.setItem(KEY,JSON.stringify(p))}
export function resetPatients(){localStorage.removeItem(KEY);return loadPatients()}
export function createPatient(p){const all=loadPatients();if(all[p.id])throw new Error("Patient ID already exists.");all[p.id]={...p,documents:[],conditions:[],illnesses:[],doctors:[],prescriptions:[],labs:[],timeline:[]};savePatients(all);return all[p.id]}
export function deletePatient(id){const all=loadPatients();delete all[id];savePatients(all)}
export function getPatient(id){return loadPatients()[id]||null}
export function updatePatient(id,fn){const all=loadPatients();if(!all[id])return;fn(all[id]);savePatients(all)}