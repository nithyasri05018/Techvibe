import {DEMO_USERS} from "../data/demo-data.js";
export function login(email,password){const u=DEMO_USERS.find(x=>x.email.toLowerCase()===email.trim().toLowerCase()&&x.password===password);if(!u)return null;const session={email:u.email,name:u.name,role:u.role};sessionStorage.setItem("mdi_session",JSON.stringify(session));return session}
export function currentUser(){try{return JSON.parse(sessionStorage.getItem("mdi_session"))}catch{return null}}
export function logout(){sessionStorage.removeItem("mdi_session")}
export function canWrite(u){return u?.role==="Admin"||u?.role==="Doctor"}
export function canDelete(u){return u?.role==="Admin"}