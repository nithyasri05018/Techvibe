export function getTimeline(patient){
 const t=[...(patient.timeline||[])];
 for(const p of patient.prescriptions||[])t.push({date:p.date,title:"Prescription",text:(p.medicines||[]).map(m=>`${m.name} ${m.dose||""} ${m.frequency||""}`).join(", ")});
 for(const l of patient.labs||[])t.push({date:l.date,title:"Lab / Investigation",text:`${l.test}: ${l.value||""} ${l.unit||""} ${l.status?`— ${l.status}`:""}`});
 return t.sort((a,b)=>b.date.localeCompare(a.date));
}