export function comparePrescriptions(patient){
 const list=(patient.prescriptions||[]).slice().sort((a,b)=>a.date.localeCompare(b.date));const rows=[];
 for(let i=1;i<list.length;i++){
  const prev=list[i-1].medicines.map(x=>x.name.toLowerCase()),cur=list[i].medicines.map(x=>x.name.toLowerCase());
  rows.push({date:list[i].date,source:list[i].source,added:cur.filter(x=>!prev.includes(x)),removed:prev.filter(x=>!cur.includes(x))});
 }
 return rows;
}
export function prescriptionText(p){return (p.medicines||[]).map(m=>`${m.name}${m.dose?" "+m.dose:""}${m.frequency?" — "+m.frequency:""}`).join(", ")}