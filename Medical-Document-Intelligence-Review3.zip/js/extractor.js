const patterns={
 dates:[/\b(20\d{2}[-/]\d{1,2}[-/]\d{1,2})\b/g,/\b(\d{1,2}[-/]\d{1,2}[-/](?:20)?\d{2})\b/g],
 doctors:/\b(?:Dr\.?|Doctor)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3})/g,
 diseases:/\b(?:diagnosis|diagnosed with|history of|condition)\s*[:\-]?\s*([A-Za-z][A-Za-z \-]{2,50})/gi,
 meds:/\b(?:Rx|medication|medicine|prescribed|tablet|tab|capsule|cap)\s*[:\-]?\s*([A-Za-z][A-Za-z\-]+(?:\s+[A-Za-z][A-Za-z\-]+){0,3})/gi,
 labs:/\b(Hemoglobin|HbA1c|glucose|blood pressure|cholesterol|LDL|HDL|creatinine|WBC|platelets)\b[^.\n]{0,80}/gi
};
export function normalizeDate(s){if(!s)return new Date().toISOString().slice(0,10);let t=s.replace(/\//g,"-").split("-");if(t[0].length===4)return t.join("-");if(t.length===3){let y=t[2].length===2?"20"+t[2]:t[2];return `${y}-${t[1].padStart(2,"0")}-${t[0].padStart(2,"0")}`}return new Date().toISOString().slice(0,10)}
export function extractMedicalData(text,fileName){
 const out={conditions:[],doctors:[],medicines:[],labs:[],dates:[],illnesses:[],timeline:[]};
 for(const r of patterns.dates[0].exec?patterns.dates:[]){let m;while((m=r.exec(text))!==null)out.dates.push(normalizeDate(m[1]))}
 let m;while((m=patterns.doctors.exec(text))!==null)out.doctors.push(m[1].trim());
 while((m=patterns.diseases.exec(text))!==null)out.conditions.push(m[1].trim());
 while((m=patterns.meds.exec(text))!==null)out.medicines.push(m[1].trim());
 while((m=patterns.labs.exec(text))!==null)out.labs.push(m[1].trim());
 const date=out.dates[0]||new Date().toISOString().slice(0,10);
 if(out.conditions.length)out.illnesses.push(...out.conditions);
 const summary=[...out.conditions.map(x=>"Condition: "+x),...out.medicines.map(x=>"Medicine: "+x),...out.labs.map(x=>"Lab: "+x)].slice(0,8).join(" • ");
 out.timeline.push({date,title:"Document analyzed",text:summary||`Extracted content from ${fileName}.`});
 return out;
}
export async function extractPdfText(file){
 if(!window.pdfjsLib){try{window.pdfjsLib=await import("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.5.136/pdf.min.mjs");window.pdfjsLib.GlobalWorkerOptions.workerSrc="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.5.136/pdf.worker.min.mjs"}catch(e){throw new Error("PDF.js could not be loaded. Check internet access and try again.")}}
 const buf=await file.arrayBuffer(),pdf=await window.pdfjsLib.getDocument({data:buf}).promise;let text="";
 for(let i=1;i<=pdf.numPages;i++){const page=await pdf.getPage(i);const c=await page.getTextContent();text+=c.items.map(x=>x.str).join(" ")+"\n"}
 return text;
}
export async function readFile(file){
 if(file.type==="application/pdf"||file.name.toLowerCase().endsWith(".pdf"))return await extractPdfText(file);
 return await file.text();
}