export const DEMO_USERS = [
  {email:"admin@demo.com",password:"Admin@123",name:"System Admin",role:"Admin"},
  {email:"doctor@demo.com",password:"Doctor@123",name:"Dr. Meera",role:"Doctor"},
  {email:"viewer@demo.com",password:"Viewer@123",name:"Clinical Viewer",role:"Viewer"}
];

export const DEMO_PATIENTS = {
 "DEMO-1001":{id:"DEMO-1001",name:"Ananya Kumar",age:29,gender:"Female",documents:[],conditions:["Iron-deficiency anemia"],illnesses:["Fever and fatigue"],doctors:["Dr. Meera Rao"],prescriptions:[
  {date:"2025-01-12",doctor:"Dr. Meera Rao",medicines:[{name:"Ferrous Sulfate",dose:"325 mg",frequency:"Once daily"}],source:"Prescription_Jan_2025.pdf"},
  {date:"2025-02-20",doctor:"Dr. Meera Rao",medicines:[{name:"Ferrous Sulfate",dose:"325 mg",frequency:"Once daily"},{name:"Paracetamol",dose:"500 mg",frequency:"As needed"}],source:"Followup_2025.pdf"}
 ],labs:[
  {date:"2025-01-10",test:"Hemoglobin",value:"9.8",unit:"g/dL",range:"12–16",status:"Low",source:"Blood_Report_2025.pdf"},
  {date:"2025-02-18",test:"Hemoglobin",value:"11.2",unit:"g/dL",range:"12–16",status:"Low",source:"Followup_2025.pdf"}
 ],timeline:[
  {date:"2025-01-10",title:"Laboratory test",text:"Hemoglobin 9.8 g/dL — Low."},
  {date:"2025-01-12",title:"Prescription",text:"Ferrous Sulfate 325 mg once daily."},
  {date:"2025-02-18",title:"Follow-up laboratory test",text:"Hemoglobin 11.2 g/dL — Low."},
  {date:"2025-02-20",title:"Follow-up consultation",text:"Continued iron therapy; paracetamol added as needed."}
 ]},
 "DEMO-1002":{id:"DEMO-1002",name:"Rahul Sharma",age:42,gender:"Male",documents:[],conditions:["Hypertension"],illnesses:["Elevated blood pressure"],doctors:["Dr. Arjun Menon"],prescriptions:[
  {date:"2025-03-04",doctor:"Dr. Arjun Menon",medicines:[{name:"Amlodipine",dose:"5 mg",frequency:"Once daily"}],source:"Prescription_Mar_2025.pdf"}
 ],labs:[{date:"2025-03-02",test:"Blood Pressure",value:"152/96",unit:"mmHg",range:"<120/80",status:"High",source:"Vitals_2025.pdf"}],
 timeline:[{date:"2025-03-02",title:"Vitals",text:"Blood pressure 152/96 mmHg — High."},{date:"2025-03-04",title:"Prescription",text:"Amlodipine 5 mg once daily."}]},
 "DEMO-1003":{id:"DEMO-1003",name:"Priya Devi",age:35,gender:"Female",documents:[],conditions:["Type 2 diabetes"],illnesses:["Hyperglycemia"],doctors:["Dr. Kavya Iyer"],prescriptions:[
  {date:"2025-04-09",doctor:"Dr. Kavya Iyer",medicines:[{name:"Metformin",dose:"500 mg",frequency:"Twice daily"}],source:"Prescription_Apr_2025.pdf"}],
 labs:[{date:"2025-04-07",test:"HbA1c",value:"7.8",unit:"%",range:"<5.7",status:"High",source:"Diabetes_Report.pdf"}],
 timeline:[{date:"2025-04-07",title:"Laboratory test",text:"HbA1c 7.8% — High."},{date:"2025-04-09",title:"Prescription",text:"Metformin 500 mg twice daily."}]},
 "DEMO-1004":{id:"DEMO-1004",name:"Arun Kumar",age:51,gender:"Male",documents:[],conditions:["Hyperlipidemia"],illnesses:["Elevated cholesterol"],doctors:["Dr. Suresh Babu"],prescriptions:[
  {date:"2025-05-15",doctor:"Dr. Suresh Babu",medicines:[{name:"Atorvastatin",dose:"20 mg",frequency:"At night"}],source:"Prescription_May_2025.pdf"}],
 labs:[{date:"2025-05-13",test:"LDL Cholesterol",value:"168",unit:"mg/dL",range:"<100",status:"High",source:"Lipid_Report.pdf"}],
 timeline:[{date:"2025-05-13",title:"Laboratory test",text:"LDL cholesterol 168 mg/dL — High."},{date:"2025-05-15",title:"Prescription",text:"Atorvastatin 20 mg at night."}]}
};